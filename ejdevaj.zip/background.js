var s = document.createElement('script');
s.src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js';
s.onload = function() {
    this.parentNode.removeChild(this);
};

(document.head||document.documentElement).appendChild(s);


var s = document.createElement('script');
s.src = chrome.extension.getURL("content.js");
s.onload = function() {
        this.parentNode.removeChild(this);
};

(document.head||document.documentElement).appendChild(s);
