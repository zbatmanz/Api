var s = document.createElement('script');
s.src = 'https://code.jquery.com/jquery-3.6.0.min.js'; // یا مسیر URL jQuery 
s.onload = function() {
    this.parentNode.removeChild(this);
};

(document.head||document.documentElement).appendChild(s);

var melewemn = "#ctl00_ContentPlaceHolder1_tbIDNo2";
var melemen = "#ctl00_ContentPlaceHolder1_tbIDNo";
var day = "#ctl00_ContentPlaceHolder1_ddlMarryDay";
var monuth= "#ctl00_ContentPlaceHolder1_ddlMarryMonth";
var year = "#ctl00_ContentPlaceHolder1_tbMarrYear";

var bday = "#ctl00$ContentPlaceHolder1$ddlBrDay";
var bmonuth= "#ctl00$ContentPlaceHolder1$ddlBrMonth";
var byear = "#ctl00$ContentPlaceHolder1$tbBrYear";

var phone = "#ctl00$ContentPlaceHolder1$tbMobileNo";




var input = $("<input type='text' id='codeMl' placeholder='شماره ملی متقاضی'>");
$("body").prepend("<div id='infoPost'></div>");
$("div#infoPost").prepend(input);
var input = $("<input type='text' id='codeMl2' placeholder='شماره ملی همسر'>");

$("div#infoPost").prepend(input);
var input = $('<tr><td dir="rtl" style="text-align: left; vertical-align: bottom;">تاریخ تولد متقاضی :</td><td style="vertical-align: bottom; text-align: right;"><select id="bday" style="color:#003300;font-family:Tahoma;font-size:8pt;font-weight:bold;width:41px;">	<option value="0">-</option><option value="01">1</option><option value="02">2</option><option value="03">3</option><option value="04">4</option><option value="05">5</option><option value="06">6</option><option value="07">7</option><option value="08">8</option><option value="09">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select>/<select id="bmonth" style="color:#003300;font-family:Tahoma;font-size:8pt;font-weight:bold;width:77px;"><option value="0">-</option><option value="01">فروردین</option><option value="02">اردیبهشت</option><option value="03">خرداد</option><option value="04">تیر</option><option value="05">مرداد</option><option value="06">شهریور</option><option value="07">مهر</option><option value="08">آبان</option><option value="09">آذر</option><option value="10">دی</option><option value="11">بهمن</option><option value="12">اسفند</option></select>/<input type="text" maxlength="4" id="BrYear" style="color:#003300;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:9pt;width:30px;">l<span id="ctl00_ContentPlaceHolder1_l7" style="color:#CC3300;font-family:Tahoma;font-size:8pt;font-weight:bold;">*</span>&nbsp;<span id="ctl00_ContentPlaceHolder1_Label66" style="color:#009900;font-family:Tahoma;font-size:8pt;">(سال 4 رقم)</span>&nbsp;<span id="ctl00_ContentPlaceHolder1_rfvBRYear" style="color:#CC3300;font-family:Tahoma;font-size:9pt;display:none;">نامعتبر (نبايد خالی باشد)</span><span id="revldBrYear" style="color:#CC3300;font-family:Tahoma;font-size:9pt;display:none;">نامعتبر (بايد 4 رقم عددی باشد)</span>&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>');
$("div#infoPost").prepend(input);
var input = $("<tr><td style='vertical-align: bottom; text-align: left'>تاریـخ ازدواج :</td><td style='vertical-align: bottom; text-align: right;'><select id='day' style='color:#003300;font-family:Tahoma;font-size:8pt;font-weight:bold;width:42px;'><option value='0'>-</option><option value='01'>1</option><option value='02'>2</option><option value='03'>3</option><option value='04'>4</option><option value='05'>5</option><option value='06'>6</option><option value='07'>7</option><option value='08'>8</option><option value='09'>9</option><option value='10'>10</option><option value='11'>11</option><option value='12'>12</option><option value='13'>13</option><option value='14'>14</option><option value='15'>15</option><option value='16'>16</option><option value='17'>17</option><option value='18'>18</option><option value='19'>19</option><option value='20'>20</option><option value='21'>21</option><option value='22'>22</option><option value='23'>23</option><option value='24'>24</option><option value='25'>25</option><option value='26'>26</option><option value='27'>27</option><option value='28'>28</option><option value='29'>29</option><option value='30'>30</option><option value='31'>31</option></select>/<select id='month' style='color:#003300;font-family:Tahoma;font-size:8pt;font-weight:bold;width:77px;'><option value='0'>-</option><option value='01'>فروردین</option><option value='02'>اردیبهشت</option><option value='03'>خرداد</option><option value='04'>تیر</option><option value='05'>مرداد</option><option value='06'>شهریور</option><option value='07'>مهر</option><option value='08'>آبان</option><option value='09'>آذر</option><option value='10'>دی</option><option value='11'>بهمن</option><option value='12'>اسفند</option></select>/<input type='text' maxlength='4' id='year' style='color:#003300;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:9pt;width:30px;'>&nbsp;<span id='ctl00_ContentPlaceHolder1_l5' style='color:#CC3300;font-family:Tahoma;font-size:8pt;font-weight:bold;'>*</span>&nbsp;<span id='ctl00_ContentPlaceHolder1_Label67' style='color:#009900;font-family:Tahoma;font-size:8pt;'>(سال 4 رقم)</span>&nbsp;<span id='ctl00_ContentPlaceHolder1_rfvMarrYear' style='color:#CC3300;font-family:Tahoma;font-size:9pt;display:none;'>نامعتبر (نبايد خالی باشد)</span><span id='ctl00_ContentPlaceHolder1_revldMarrYear' style='color:#CC3300;font-family:Tahoma;font-size:9pt;display:none;'>نامعتبر (بايد 4 رقم عددی باشد)</span></td></tr>");
$("div#infoPost").prepend(input);
var input = $("<tr><td><input type='text' id='phone' placeholder='شماره تلفن همراه متقاضی :'></tr></td>");

$("div#infoPost").prepend(input);

var button= $("<button id='myButton' >اجرای ربات</button>");

$("div#infoPost").prepend(button);
$("#myButton").click(function(){
  var inputValue = $("#codeMl").val();
  var inputValue2 = $("#codeMl2").val();
  var inputValue3 = $("#day").val();
  var inputValue4 = $("#month").val();
  var inputValue5 = $("#year").val();
  var inputValue6 = $("#bday").val();
  var inputValue7 = $("#bmonth").val();
  var inputValue8 = $("#BrYear").val();
  var inputValue9 = $("#phone").val();
  $(melewemn).val(inputValue2);
  $(melemen).val(inputValue);
  $(day).val(inputValue3);
  $(monuth).val(inputValue4);
  $(year).val(inputValue5);
  $(bday).val(inputValue6);
  $(bmonuth).val(inputValue7);
  $(byear).val(inputValue8);
  $(phone).val(inputValue9);
});